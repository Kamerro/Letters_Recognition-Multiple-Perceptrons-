﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nuron__1
{
    class Perceptron
    {
        public string label;
        //Below private properties of single perceptron
        private double bias;
        private bool predicted_label;
        private sbyte sign;
        //Weights for the inputs.
        //property = more control when i need to modif this.
        private double[,] enters_weights{ get; set; }
        private double learning_step;
        //Width:number of inputs in x axis.
        private int width;
        //Height:number of inputs in y axis.
        private int height;
        //Private random :)
        private Random rand = new Random();

        //Below multiple constructors.
        public Perceptron(int x,int y)
        {
            this.width = x;
            this.height = y;
            this.enters_weights = new double[this.width,this.height];
            setEntersWeights();
        }
        public Perceptron(double learning_step)
        {
            this.learning_step = learning_step;
        }
        public Perceptron(int x,int y, double learning_step)
        {
            this.width = x;
            this.height = y;
            this.enters_weights = new double[this.width, this.height];
            this.learning_step = learning_step;
            setEntersWeights();
        }

      
        //Below function that make random weights for inputs.
        public void setEntersWeights(){
            //initial bias is very low. This make possible to better train perceptron.
            this.bias = -1000;
            for(int i = 0; i < this.width; i++)
            {
                for(int j = 0; j < this.height; j++) {

                    //Set the weight from -1 to 1.
                    this.enters_weights[i,j] = (rand.NextDouble() - 0.5) * 2;
                }
            }
        }

        public void calcNewWages(byte[,] inputValues)
        {
            this.bias += this.sign*this.learning_step;
            for(int i = 0; i < width; i++)
            {
                for(int j = 0; j < height; j++)
                {
                    this.enters_weights[i, j] += (inputValues[i, j]-0.5)*2*this.sign*this.learning_step;
                }
            }
        }
        //returns weights of the perceptron inputs
        public double[,] getWeights()
        {
            return this.enters_weights;
        }
        // peturn bias of the perceptron
        public double getBias()
        {
            return this.bias;
        }
        public void set_predicted_label(bool value)
        {
            this.predicted_label = value;
        }
        public bool get_predicted_label()
        {
            return this.predicted_label;
        }
        public void setSign(ConfigurationOfTraining cnfg)
        {
            if (this.predicted_label == true && cnfg.getLabel() == false)
            {
                this.sign = -1;
            }
            else if (this.predicted_label == false && cnfg.getLabel() == true)
            {
                this.sign = 1;
            }
            else
                this.sign = 0;
        }

        public double Tanh(double x)
        {
            double e2x = Math.Exp(2 * x);
            return (e2x - 1) / (e2x + 1)-0.5;
        }


        public void setLabel(string label)
        {
            this.label = label;
        }
    }
}
