﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nuron__1
{
    //internal class that contains images and input values to perceptrons.
    internal class DataSet
    {
        //images ok
        static public List<Image> OKA;
        static public List<Image> OKB;
        static public List<Image> OKC;


        //images test
        static public List<Image> dataSetTest;
        //images nok
        static public List<Image> dataSetNok;
        //props
        static public int pictureWidth;
        static public int pictureHeight;
        //test vals
        static public List<byte[,]> testInputs = new List<byte[,]>();
        //nok vals
        static public List<byte[,]> NokInputs = new List<byte[,]>();
    }
}
