﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nuron__1
{


    /// <summary>
    /// The place where will be placed the learning properties, that change the values while training.
    /// </summary>
    internal class ConfigurationOfTraining
    {
        // true value of label means, the data set have good examples. false means, that dataset have bad examples 
        private bool label = true;
        public void setLabel(bool value)
        {
            this.label = value;
        }

        public bool getLabel()
        {
            return this.label;
        }

    }
}
