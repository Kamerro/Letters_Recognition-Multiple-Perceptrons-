﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AForge.Imaging;
using AForge.Imaging.Filters;
namespace Nuron__1
{


    //Internal class that holds static functions for image manipulation.
    internal class filteringBitmap
    {
    
        //Function that binarize the input image.
        static internal Bitmap filterBinarization(Bitmap input_bitmap)
        {
            //Needed components. 
            Bitmap output_Bitmap = new Bitmap(input_bitmap.Width, input_bitmap.Height);
            Color color;
            //Binerization the bitmap
            for(int width = 0; width < output_Bitmap.Width; width++)
            {
                for (int height = 0; height < output_Bitmap.Height; height++)
                {
                    color = input_bitmap.GetPixel(width, height);
                    //For clarity what exactly the thresholding function is.
                    if ((color.R + color.G + color.B)>(256/2 + 256/2 + 256/2)) // treshold is half.
                    {
                        output_Bitmap.SetPixel(width, height, Color.White); // if there is value below treshold
                        //the area is now white.
                    }
                    else
                        output_Bitmap.SetPixel(width, height, Color.Black);
                    //There could be other tresholds, but this is simple algorithm.
                }
            }
            //Return new bitmap
            return output_Bitmap;
        }


        static internal Bitmap filterLaplacian(Bitmap input_bitmap)
        {
            Bitmap output_Bitmap = new Bitmap(input_bitmap.Width, input_bitmap.Height);
            //Firstly we need to convert bitmap into gryascale colors/binary bitmap. We 
            //Don't have gray scale filter, so we will use binarization.
            input_bitmap = filteringBitmap.filterBinarization(input_bitmap);
            //Laplacian needs 9 colors. so:
            Color color_0_0; // -> top left corner 
            Color color_0_1;
            Color color_0_2; // -> top right corner
            Color color_1_0;
            Color color_1_1; // Middle colour -> Center !
            Color color_1_2;
            Color color_2_0; // ->bottom left corner
            Color color_2_1;
            Color color_2_2; // -> bottm right corner
            //Binerization the bitmap
            //Edges have to be skipped.
            for (int width = 1; width < output_Bitmap.Width-1; width++)
            {
                for (int height = 1; height < output_Bitmap.Height-1; height++)
                {
                   color_0_0 = input_bitmap.GetPixel(width - 1, height - 1);
                   color_0_1 = input_bitmap.GetPixel(width    , height - 1);
                   color_0_2 = input_bitmap.GetPixel(width + 1, height - 1);
                   color_1_0 = input_bitmap.GetPixel(width - 1, height    );
                   color_1_1 = input_bitmap.GetPixel(width    , height    );
                   color_1_2 = input_bitmap.GetPixel(width + 1, height    );
                   color_2_0 = input_bitmap.GetPixel(width - 1, height + 1);
                   color_2_1 = input_bitmap.GetPixel(width    , height + 1);
                   color_2_2 = input_bitmap.GetPixel(width + 1, height + 1);

                    //sumColors calculate Laplacian 8*middlePixel - SUM(otherPixels);
                   output_Bitmap.SetPixel(width, height, sumColors(color_0_0, color_0_1, color_0_2,
                                                                   color_1_0, color_1_1, color_1_2,
                                                                   color_2_0, color_2_1, color_2_2));

                    
                    //There could be other tresholds, but this is simple algorithm.
                }
            }
            //Return new bitmap
            return output_Bitmap;
        }

        private static Color sumColors(Color color_0_0, Color color_0_1, Color color_0_2, Color color_1_0, Color color_1_1, Color color_1_2, Color color_2_0, Color color_2_1, Color color_2_2)
        {
            int ColorR;
            int ColorG;
            int ColorB;
            //Calculate the value that is based on the neighbours.
            ColorR = 8 * color_1_1.R - (color_0_0.R + color_0_1.R + color_0_2.R
                                     +  color_1_0.R + color_1_2.R + color_2_0.R
                                     +  color_2_1.R + color_2_2.R);


            ColorG = 8 * color_1_1.G - (color_0_0.G + color_0_1.G + color_0_2.G
                                     +  color_1_0.G + color_1_2.G + color_2_0.G
                                     +  color_2_1.G + color_2_2.G);

            ColorB = 8 * color_1_1.B - (color_0_0.B + color_0_1.B + color_0_2.B
                                    +   color_1_0.B + color_1_2.B + color_2_0.B
                                    +   color_2_1.B + color_2_2.B);

            //Check if the values are valid.
            //R
            if (ColorR < 0)
            {
                ColorR = 0;
            }
            else if (ColorR > 255)
            {
                ColorR = 255;
            }

            //G
            if (ColorG < 0)
            {
                ColorG = 0;
            }
            else if (ColorG > 255)
            {
                ColorG = 255;
            }
           
            //B
            if (ColorB < 0)
            {
                ColorB = 0;
            }
            else if (ColorB > 255)
            {
                ColorB = 255;
            }

            return Color.FromArgb(ColorR, ColorG, ColorB);
        }

        public static Bitmap ResizeBitmap(Bitmap sourceBMP, int width, int height)
        {
            Bitmap result = new Bitmap(width, height);
            using (Graphics g = Graphics.FromImage(result))
            {
                g.DrawImage(sourceBMP, 0, 0, width, height);
            }
            return result;
        }

        internal static Bitmap FourierTransform(Bitmap bitmap)
        {
            Bitmap resized = ResizeBitmap(bitmap, 256, 256);
            // Przekształć obraz do skali szarości
            Grayscale filter = new Grayscale(1, 1, 1);
            Bitmap grayImage = filter.Apply(resized);
            // Tworzenie instancji transformacji Fouriera
            ComplexImage complexImage = ComplexImage.FromBitmap(grayImage);
            // Wykonaj transformację Fouriera
            complexImage.ForwardFourierTransform();

            // Zapisz obraz po transformacji
            Bitmap fourierImage = complexImage.ToBitmap();

            return fourierImage;

        }
    }
}
