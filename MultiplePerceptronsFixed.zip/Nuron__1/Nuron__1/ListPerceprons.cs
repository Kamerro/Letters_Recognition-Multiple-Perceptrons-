﻿using System;
using System.Collections.Generic;

namespace Nuron__1
{
    //Class that contains list of perceptrons.
    internal class ListPerceprons
    {
        //properties of the list.
        private int perceptrons;
        private int width;
        private int height;
        private double learning_step;
       

        public List<Perceptron> listPerceptrons = new List<Perceptron>();

        public ListPerceprons(int perceptrons, double learning_step,int x, int y)
        {
            this.perceptrons = perceptrons;
            this.learning_step = learning_step;
            this.width = x;
            this.height = y;
            generatePerceptron(this.perceptrons);
            Parameters.width = this.width;
            Parameters.height = this.height;
            Parameters.perceptrons = this.perceptrons;
            Parameters.calcTotalInputs();
        }
        private void generatePerceptron(int perceptrons)
        {
            for (int i = 0; i < perceptrons; i++)
            {
                listPerceptrons.Add(new Perceptron(learning_step: this.learning_step, x: this.width, y: this.height));
            }
        }

        public double[] sumOfWeights;

        public void setSumOfWeights(int size)
        {
            this.sumOfWeights = new double[size];
        }

    }
}