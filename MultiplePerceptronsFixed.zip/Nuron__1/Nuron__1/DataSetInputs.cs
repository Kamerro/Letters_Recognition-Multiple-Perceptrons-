﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nuron__1
{
    public class DataSetInputs
    {
        public List<byte[,]> inputs = new List<byte[,]>();
    }
}
