﻿
namespace Nuron__1
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.ResetImage = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.SizeOfPen = new System.Windows.Forms.TrackBar();
            this.label6 = new System.Windows.Forms.Label();
            this.Answer = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblPrecise = new System.Windows.Forms.Label();
            this.DrawLetter = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.SizeOfPen)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DrawLetter)).BeginInit();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label4.Location = new System.Drawing.Point(11, 7);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(227, 29);
            this.label4.TabIndex = 14;
            this.label4.Text = "Draw any letter here";
            // 
            // ResetImage
            // 
            this.ResetImage.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.ResetImage.Location = new System.Drawing.Point(153, 420);
            this.ResetImage.Name = "ResetImage";
            this.ResetImage.Size = new System.Drawing.Size(163, 38);
            this.ResetImage.TabIndex = 15;
            this.ResetImage.Text = "Reset Image";
            this.ResetImage.UseVisualStyleBackColor = true;
            this.ResetImage.Click += new System.EventHandler(this.ResetImage_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label5.Location = new System.Drawing.Point(508, 281);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(93, 20);
            this.label5.TabIndex = 16;
            this.label5.Text = "Size of pen";
            // 
            // SizeOfPen
            // 
            this.SizeOfPen.Location = new System.Drawing.Point(512, 222);
            this.SizeOfPen.Name = "SizeOfPen";
            this.SizeOfPen.Size = new System.Drawing.Size(104, 56);
            this.SizeOfPen.TabIndex = 17;
            this.SizeOfPen.ValueChanged += new System.EventHandler(this.SizeOfPen_ValueChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.Location = new System.Drawing.Point(12, 500);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 22);
            this.label6.TabIndex = 18;
            this.label6.Text = "Answer:";
            // 
            // Answer
            // 
            this.Answer.AutoSize = true;
            this.Answer.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Answer.Location = new System.Drawing.Point(104, 495);
            this.Answer.Name = "Answer";
            this.Answer.Size = new System.Drawing.Size(120, 29);
            this.Answer.TabIndex = 19;
            this.Answer.Text = "Unknown";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(263, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 22);
            this.label1.TabIndex = 20;
            this.label1.Text = "Avaiable A,B,C";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.DimGray;
            this.panel1.Controls.Add(this.lblPrecise);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.Answer);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.DrawLetter);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.SizeOfPen);
            this.panel1.Controls.Add(this.ResetImage);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(500, 501);
            this.panel1.TabIndex = 11;
            // 
            // lblPrecise
            // 
            this.lblPrecise.AutoSize = true;
            this.lblPrecise.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.lblPrecise.Location = new System.Drawing.Point(185, 463);
            this.lblPrecise.Name = "lblPrecise";
            this.lblPrecise.Size = new System.Drawing.Size(0, 22);
            this.lblPrecise.TabIndex = 21;
            // 
            // DrawLetter
            // 
            this.DrawLetter.BackColor = System.Drawing.Color.Black;
            this.DrawLetter.Location = new System.Drawing.Point(16, 44);
            this.DrawLetter.Name = "DrawLetter";
            this.DrawLetter.Size = new System.Drawing.Size(256, 256);
            this.DrawLetter.TabIndex = 13;
            this.DrawLetter.TabStop = false;
            this.DrawLetter.MouseDown += new System.Windows.Forms.MouseEventHandler(this.DrawLetter_MouseDown);
            this.DrawLetter.MouseMove += new System.Windows.Forms.MouseEventHandler(this.DrawLetter_MouseMove);
            this.DrawLetter.MouseUp += new System.Windows.Forms.MouseEventHandler(this.DrawLetter_MouseUp);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(523, 523);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Perceptron";
            ((System.ComponentModel.ISupportInitialize)(this.SizeOfPen)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DrawLetter)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button ResetImage;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TrackBar SizeOfPen;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label Answer;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblPrecise;
        private System.Windows.Forms.PictureBox DrawLetter;
    }
}

