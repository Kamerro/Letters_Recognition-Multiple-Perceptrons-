﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nuron__1
{
    public class SettingsDrawLetter
    {
        static public int width = 300;
        static public int height = 300;
        static public Color basicColor = Color.Black;
        static public int sizeOfPen = 8;
        static public int maxSizeOfPen = 15;
        static public int minSizeOfPen = 8;

        static public byte[,] arrayDrawLetter;

    }
}
