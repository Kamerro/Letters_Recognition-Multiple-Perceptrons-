﻿namespace Nuron__1
{
    internal class Parameters
    {
        //Width contains number of inputs for perceptron in x axis
        public static int width;
        //Height contains number of inputs for perceptron in y axis
        public static int height;
        //Total_inputs conains total number of inputs in one perceptron(width*height)
        public static int total_inputs;
        //Perceptrons contains number of perceptron
        public static int perceptrons;
        public static void calcTotalInputs()
        {
            total_inputs = width * height;
        }
    }
}