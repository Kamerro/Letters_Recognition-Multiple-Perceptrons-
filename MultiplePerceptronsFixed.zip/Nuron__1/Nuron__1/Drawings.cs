﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Nuron__1
{
    public class Drawings
    {

        public static PictureBox DrawBlackInDrawLetter(PictureBox pctrBox)
        {
            Bitmap btmp = new Bitmap(pctrBox.Width, pctrBox.Height);
            for (int i = 0; i < pctrBox.Width; i++)
            {
                for (int j = 0; j < pctrBox.Height; j++)
                {
                    btmp.SetPixel(i, j, Color.Black);
                }
            }
            pctrBox.Image = btmp;
            return pctrBox;
        }
    }
}
