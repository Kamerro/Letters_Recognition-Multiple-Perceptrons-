﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Nuron__1
{
    public partial class Form1 : Form
    {


        /// <summary>
        /// global variables.
        /// </summary>



        ListPerceprons perceptronList;
        int indexTestedImage = 0;
        /// <summary>
        /// Initialize component, make an X perceptrons, read the images from dictionary
        /// Make an arrays of digital inputs
        /// Percepron need to be ready for inicialization after ini.
        /// 
        /// </summary>
        /// 
        ///
        public Form1()
        {
            InitializeComponent();
            insertImagesIntoDataset();
            //Reading width and height of dataset pictures.
            readSizeOfData();
            //Adding names images in dataset
            setPropertiesOfPerceptronAndDrawImage();
            createListOfDataSetInputs();
            makeBinarizationOfTheData();
            setPerceptronLabels();
            setDrawProperties();
            TrainModel();
            DrawMode();
           
        }
/// <summary>
/// Setting proper dimensions.
/// </summary>
        private void readSizeOfData()
        {
            DataSet.pictureWidth = DataSet.OKA[0].Width;
            DataSet.pictureHeight = DataSet.OKA[0].Height;
        }

/// <summary>
/// Setting properies into classes that allow to draw.
/// </summary>
        private void setDrawProperties()
        {
            SizeOfPen.Value = SettingsDrawLetter.sizeOfPen;
            SizeOfPen.Maximum = SettingsDrawLetter.maxSizeOfPen;
            SizeOfPen.Minimum = SettingsDrawLetter.minSizeOfPen;
            DrawLetter.Size = new Size(300, 300);
            DrawLetter = Drawings.DrawBlackInDrawLetter(DrawLetter);
        }
/// <summary>
/// Function that allow to add binarized data into byte tables, that will be seen in perceptron input.
/// </summary>
        private void makeBinarizationOfTheData()
        {
            for (int i = 0; i < DataSet.OKA.Count; i++)
            {
                DataSetListInputs.dataSetInputs[0].inputs.Add(makeBitsFromImage(filteringBitmap.filterBinarization((Bitmap)DataSet.OKA[i]), DataSet.pictureWidth / Parameters.width));
            
            }

            for (int i = 0; i < DataSet.OKB.Count; i++)
            {
                DataSetListInputs.dataSetInputs[1].inputs.Add(makeBitsFromImage(filteringBitmap.filterBinarization((Bitmap)DataSet.OKB[i]), DataSet.pictureWidth / Parameters.width));
               //Sprawdzenie w jaki sposób wygląda transformata fouriera dla określonego obrazu
                //if (i == DataSet.OKB.Count - 2)
                //{
                //    FormaShow formaShow = new FormaShow();
                //    formaShow.ShowLetter.Image = filteringBitmap.FourierTransform((Bitmap)DataSet.OKB[i]);
                //    formaShow.ShowLetter.Size = new Size(256, 256);
                //    formaShow.Show();
                //}
            }

            for (int i = 0; i < DataSet.OKC.Count; i++)
            {
                if (i == DataSet.OKC.Count - 2)
                {
                    FormaShow formaShow = new FormaShow();
                }
                DataSetListInputs.dataSetInputs[2].inputs.Add(makeBitsFromImage(filteringBitmap.filterBinarization((Bitmap)DataSet.OKC[i]), DataSet.pictureWidth / Parameters.width));
            }
            for (int i = 0; i < DataSet.dataSetTest.Count; i++)
            {
                DataSet.testInputs.Add(makeBitsFromImage(filteringBitmap.filterBinarization((Bitmap)DataSet.dataSetTest[i]), DataSet.pictureWidth / Parameters.width));
            }
            for (int i = 0; i < DataSet.dataSetNok.Count; i++)
            {
                DataSet.NokInputs.Add(makeBitsFromImage(filteringBitmap.filterBinarization((Bitmap)DataSet.dataSetNok[i]), DataSet.pictureWidth / Parameters.width));
            }
        }
/// <summary>
/// Creating list of types of inputs (ABCDE) one Perceptron, one DataSetInput.
/// </summary>
        private void createListOfDataSetInputs()
        {
            for (int i = 0; i < perceptronList.listPerceptrons.Count; i++)
            {
                DataSetInputs obj = new DataSetInputs();
                DataSetListInputs.dataSetInputs.Add(obj);
            }
        }

/// <summary>
/// Inserting properties, the birth of the perceptrons, and also birth of an DrawLetter array.
/// </summary>
        private void setPropertiesOfPerceptronAndDrawImage()
        {
            //Making new perceptrons that have 25x25 enters (can change to 5/10/20 /50->not recommended)
            //Save parameters to list of perceptrons                                 enters
            perceptronList = new ListPerceprons(perceptrons: 5, learning_step: 0.5, x: 20, y: 20);
            //Also setting parameters to the array that contains draw image.
            SettingsDrawLetter.arrayDrawLetter = new byte[Parameters.width, Parameters.height];
            perceptronList.setSumOfWeights(perceptronList.listPerceptrons.Count);
        }

/// <summary>
/// Inserting images to the proper DataSet.
/// </summary>
        private void insertImagesIntoDataset()
        {
            string OKA = $@"{AppDomain.CurrentDomain.BaseDirectory}\DataSet\OKA\";
            //Now I have access in my program to all images in form of list
            DataSet.OKA = Directory.GetFiles(OKA, "*.jpg",
                                      SearchOption.AllDirectories)
                                     .Select(Image.FromFile).ToList(); // <--- List :)
                                                                       // all pictures have the same size, so I can use [0] picture to catch size
                                                                       //Adding all images to checklistbox.
                                                                       //making the List of Images for tests.
            string OKB = $@"{AppDomain.CurrentDomain.BaseDirectory}\DataSet\OKB\";
            //Now I have access in my program to all images in form of list
            DataSet.OKB = Directory.GetFiles(OKB, "*.jpg",
                                      SearchOption.AllDirectories)
                                     .Select(Image.FromFile).ToList();

            string OKC = $@"{AppDomain.CurrentDomain.BaseDirectory}\DataSet\OKC\";
            //Now I have access in my program to all images in form of list
            DataSet.OKC = Directory.GetFiles(OKC, "*.jpg",
                                       SearchOption.AllDirectories)
                                      .Select(Image.FromFile).ToList();

            string imagesTest = $@"{AppDomain.CurrentDomain.BaseDirectory}\DataSet\DataSetTest\";
            //Now I have access in my program to all images in form of list
            DataSet.dataSetTest = Directory.GetFiles(imagesTest, "*.jpg",
                                      SearchOption.AllDirectories)
                                     .Select(Image.FromFile).ToList();

            //making the list of images that are NOK
            string imagesNok = $@"{AppDomain.CurrentDomain.BaseDirectory}\DataSet\DataNok\";
            //Now I have access in my program to all images in form of list
            DataSet.dataSetNok = Directory.GetFiles(imagesNok, "*.jpg",
                                      SearchOption.AllDirectories)
                                     .Select(Image.FromFile).ToList();
        }

/// The function in main view, calculates values used to train perceptrons
/// </summary>
/// <param name="inputs"></param>
/// <param name="image"></param>
/// <param name="range"></param>
/// <summary>
        private byte[,] makeBitsFromImage(Image image, int range)
        {
            //Make new byteArray, that will contain values for specific image
            // Range means that what is an actuall jump between one entry of perceptron and another.
            byte[,] byteArrItem = new byte[image.Width / range, image.Height / range];
            for (int width = 0; width < image.Width; width += range)
            {
                for (int height = 0; height < image.Height; height += range)
                {
                    //Calculate values for specific places in matrix.(perceptron input values)
                    byteArrItem[width / range, height / range] = calculateValue(width, height, range, image, percentage: 40);
                }
            }

            //After calculating, the array may be add to input list in DataSet class. There is now digital
            //representation for some image from training set.
            return byteArrItem;
        }
/// <summary>
/// Helping function, that helps to change color from images in dataset into binary. 
/// </summary>
/// <param name="width"></param>
/// <param name="height"></param>
/// <param name="range"></param>
/// <param name="image"></param>
/// <returns></returns>
        private byte calculateValue(int width, int height, int range, Image image, double percentage)
        { 
            //Make bitmap from image.
            Bitmap btmp = (Bitmap)image;
            //initialize sum of the colored pixels = 0;
            int sumOfColoredPixels = 0;
            Color color;
            for (int xPixel = width; xPixel < width + range; xPixel++)
            {
                for (int yPixel = height; yPixel < height + range; yPixel++)
                {
                    color = btmp.GetPixel(xPixel, yPixel);
                    //Fourier 30, binarization 255
                    if (color.R == 255)
                    {
                        sumOfColoredPixels += 1;
                    }
                }
            }
            //Check if the sum of colored pixels is more than x% of total numbers of pixels.
            if (sumOfColoredPixels > (percentage * range * range) / 100)
                return 1;

            return 0;
        }

/// <summary>
/// Setting proper labels for the perceptrons. Here is the Assumtion what they are trained for.
/// </summary>
        public void setPerceptronLabels()
        {
                perceptronList.listPerceptrons[0].setLabel("A");
                perceptronList.listPerceptrons[1].setLabel("B");
                perceptronList.listPerceptrons[2].setLabel("C");
        }

 /// <summary>
 /// Calculating new values each time the mouse button is realised.
 /// </summary>
        public void calculateNewValues()
        {
            makeBitsFromDrawingArea(DrawLetter.Image, ref SettingsDrawLetter.arrayDrawLetter, DrawLetter.Width / Parameters.width);
        }

        public void makeBitsFromDrawingArea(Image image,ref byte[,] arrayOfBits,int range)
        {
            //Make new byteArray, that will contain values for specific image
            // byte[,] byteArrItem = new byte[image.Width / (int)(range*scale), image.Height / (int)(range*scale)];
            for (int width = 0; width < image.Width; width += range)
            {
                for (int height = 0; height <image.Height; height += range)
                {
                    try
                    {
                        //Calculate values for specific places in matrix.(perceptron input values)
                        arrayOfBits[width / range, height / range] = calculateValue(width, height, range, image, percentage: 40);
                    }
                    catch { }
                }
            }
            //FormaShow frn = new FormaShow();
            //frn.ShowLetter.Image = filteringBitmap.FourierTransform((Bitmap)image);
            //frn.ShowLetter.Size = new Size(256, 256);
            //frn.Size = new Size(300, 300);
            //frn.Show();
        }
        //For training
       private void TrainModel()
        {
            // Amount of training epochs is 100.
            for (int epochs = 0; epochs < 200; epochs++)
            {

                for (int i = 0; i < perceptronList.listPerceptrons.Count; i++)
                {
                    //Training perceptrons.
                    trainPerceptron(i);
                }

            }
        }

        private void setTheSizeOfWindow(int v1, int v2)
        {
            this.Width = v1;
            this.Height = v2;
        }

        /// <summary>
        /// Quite complicated function. Taking all good examples of Letter, take all bad examples and also train it.
        /// All data is put into train.
        /// </summary>
        /// <param name="perceptron"></param>
        /// <param name="ValueOfTraining"></param>
        private void trainPerceptron(int perceptron)
        {
            //Take a list of inputs of good examples and save it.
            List<byte[,]> inputs = DataSetListInputs.dataSetInputs[perceptron].inputs;
            //weights of good data
            double[,] perceptronWeights = new double[Parameters.width,Parameters.height];

            //Create new config
            //config initionally is true, that means good examples will be shown.
            ConfigurationOfTraining config = new ConfigurationOfTraining();

            //Training from data:

            //Train from OK data
            trainOkData(ref inputs, config, perceptron,perceptronWeights);
            //Reverse an inputs 
            inputs.Reverse();
            config.setLabel(false);

            //Now train NOK data from the samples of NOK data. Later will be train NOK data from other letters.
            trainNOKData(ref inputs,config,perceptron,perceptronWeights);
            inputs.Reverse();

            //train from other letters.
            trainFromOtherLettersNOKData(ref inputs,config,perceptron,perceptronWeights);
            
            DataSet.NokInputs.Reverse();
            perceptronWeights = perceptronList.listPerceptrons[perceptron].getWeights();
        }

/// <summary>
/// Train NOK data from other examples (ABCDE);
/// </summary>
/// <param name="inputs"></param>
/// <param name="config"></param>
/// <param name="perceptron"></param>
/// <param name="perceptronWeights"></param>
        private void trainFromOtherLettersNOKData(ref List<byte[,]> inputs, ConfigurationOfTraining config, int perceptron, double[,] perceptronWeights)
        {
            double sum;
            bool predictedValue;
            for (int prcptron = 0; prcptron < perceptronList.listPerceptrons.Count; prcptron++)
            {
                if (prcptron == perceptron)
                {
                    continue;
                }
                foreach (byte[,] transformedImage in DataSetListInputs.dataSetInputs[prcptron].inputs)
                {
                    sum = 0;
                    perceptronWeights = perceptronList.listPerceptrons[perceptron].getWeights();
                    double bias = perceptronList.listPerceptrons[perceptron].getBias();
                    sum += bias;
                    //Sum all the inputs from dataset image, multiple them times the wages, sum and subtract bias.
                    //if the output >0, then predicion is true. if not, false.
                    for (int i = 0; i < Parameters.width; i++)
                    {
                        for (int j = 0; j < Parameters.height; j++)
                        {
                            sum += perceptronWeights[i, j] * (((double)transformedImage[i, j] - 0.5) * 2);

                        }
                    }
                    //calc new predicted value based on sum.
                    predictedValue = calcPredictedValue(sum);
                    perceptronList.listPerceptrons[perceptron].set_predicted_label(predictedValue);
                    perceptronList.listPerceptrons[perceptron].setSign(config);
                    //Check if the predicion was good. If not, change wages of perceptron.
                    if (!(perceptronList.listPerceptrons[perceptron].get_predicted_label() == config.getLabel()))
                    {
                        perceptronList.listPerceptrons[perceptron].calcNewWages(transformedImage);
                    }
                }
            }
        }
/// <summary>
/// Train NOK data from DataSetNOK examples
/// </summary>
/// <param name="inputs"></param>
/// <param name="config"></param>
/// <param name="perceptron"></param>
/// <param name="perceptronWeights"></param>
        private void trainNOKData(ref List<byte[,]> inputs, ConfigurationOfTraining config, int perceptron, double[,] perceptronWeights)
        {
            double sum;
            bool predictedValue;
            foreach (byte[,] transformedImage in DataSet.NokInputs)
            {
               
                sum = 0;
                perceptronWeights = perceptronList.listPerceptrons[perceptron].getWeights();
                double bias = perceptronList.listPerceptrons[perceptron].getBias();
                sum += bias;
                //Sum all the inputs from dataset image, multiple them times the wages, sum and subtract bias.
                //if the output >0, then predicion is true. if not, false.
                for (int i = 0; i < Parameters.width; i++)
                {
                    for (int j = 0; j < Parameters.height; j++)
                    {
                        sum += perceptronWeights[i, j] * (((double)transformedImage[i, j] - 0.5) * 2);

                    }
                }
                //calc new predicted value based on sum.
                predictedValue = calcPredictedValue(sum);
                perceptronList.listPerceptrons[perceptron].set_predicted_label(predictedValue);
                perceptronList.listPerceptrons[perceptron].setSign(config);
                //Check if the predicion was good. If not, change wages of perceptron.
                if (!(perceptronList.listPerceptrons[perceptron].get_predicted_label() == config.getLabel()))
                {
                    perceptronList.listPerceptrons[perceptron].calcNewWages(transformedImage);
                }
            }
        }
/// <summary>
/// Train OK data
/// </summary>
/// <param name="inputs"></param>
/// <param name="config"></param>
/// <param name="perceptron"></param>
/// <param name="perceptronWeights"></param>
        private void trainOkData(ref List<byte[,]> inputs, ConfigurationOfTraining config, int perceptron,double[,] perceptronWeights)
        {
            double sum;
            bool predictedValue;
            foreach (byte[,] transformedImage in inputs)
            {
                sum = 0;
                //read all needed values.
                perceptronWeights = perceptronList.listPerceptrons[perceptron].getWeights();
                double bias = perceptronList.listPerceptrons[perceptron].getBias();
                sum = 0;
                sum += bias;
                //Sum all the inputs from dataset image, multiple them times the wages, sum and subtract bias.
                //if the output >0, then predicion is true. if not, false.
                for (int i = 0; i < Parameters.width; i++)
                {
                    for (int j = 0; j < Parameters.height; j++)
                    {
                        sum += perceptronWeights[i, j] * (((double)transformedImage[i, j] - 0.5) * 2);

                    }
                }
                //calc new predicted value based on sum.
                predictedValue = calcPredictedValue(sum);
                perceptronList.listPerceptrons[perceptron].set_predicted_label(predictedValue);
                perceptronList.listPerceptrons[perceptron].setSign(config);
                //Check if the predicion was good. If not, change wages of perceptron.
                if (!(perceptronList.listPerceptrons[perceptron].get_predicted_label() == config.getLabel()))
                {
                    perceptronList.listPerceptrons[perceptron].calcNewWages(transformedImage);
                }
            }
        }
//Calc the predicted value.
        private bool calcPredictedValue(double sum)
        {
            if (sum > 0)
                return true;
            
                return false;
        }

       private void DrawMode()
        {
            setTheSizeOfWindow(600, 600);
            panel1.Size = new Size(this.Width-35, this.Height-58);
            DrawLetter.Size = new Size(300, 300);
        }

        private void DrawLetter_MouseDown(object sender, MouseEventArgs e)
        {
            mouseDown = true;
        }
        bool mouseDown = false;
        private void DrawLetter_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouseDown)
            {
                Bitmap btmp = new Bitmap(DrawLetter.Width, DrawLetter.Height);
                btmp = (Bitmap)DrawLetter.Image;
                for (int i = -SettingsDrawLetter.sizeOfPen; i <SettingsDrawLetter.sizeOfPen; i++)
                {
                    for (int j = -SettingsDrawLetter.sizeOfPen; j < SettingsDrawLetter.sizeOfPen; j++)
                    {
                       if(e.Location.X + i < DrawLetter.Width && e.Location.X + i >= 0 
                       && e.Location.Y + j < DrawLetter.Height && e.Location.Y + j >= 0)
                            btmp.SetPixel(e.Location.X + i, e.Location.Y + j, Color.White);
                     

                    }
                }
                DrawLetter.Image = btmp;
            }
        }

        //Function that check what the real letter is. 
        public void checkWhatLetterIs()
        {
            double[,] perceptronWeights;
           
            double sum;
            for (int perceptron = 0; perceptron < perceptronList.listPerceptrons.Count; perceptron++)
            {
                perceptronWeights = perceptronList.listPerceptrons[perceptron].getWeights();
                double bias = perceptronList.listPerceptrons[perceptron].getBias();
                byte[,] testedImage = SettingsDrawLetter.arrayDrawLetter;
                sum = 0;
                sum += bias;

                for (int i = 0; i < Parameters.width; i++)
                {
                    for (int j = 0; j < Parameters.height; j++)
                    {
                        sum += perceptronWeights[i, j] * (((double)testedImage[i, j] - 0.5) * 2);
                    }
                }
                perceptronList.sumOfWeights[perceptron] = perceptronList.listPerceptrons[perceptron].Tanh(sum);
               // MessageBox.Show(perceptronList.sumOfWeights[perceptron].ToString());
            }
            int index = CalculateIndex();
            if (index != -1)
            {
                Answer.Text = perceptronList.listPerceptrons[index].label;
                lblPrecise.Text = "";
            }

            else
            {
                Answer.Text = "Unknow, draw more precise image.";
                //lblPrecise.Text = "Draw more precise image!";
            }
            

        }
//Calc the index of the perceptron.
        private int CalculateIndex()
        {
            int indexOfHighestValue = 0;
            for (int perceptron = 1; perceptron < perceptronList.listPerceptrons.Count; perceptron++)
            {
                if(perceptronList.sumOfWeights[perceptron] > perceptronList.sumOfWeights[indexOfHighestValue])
                {
                    indexOfHighestValue = perceptron;
                }
                //if((double)perceptronList.sumOfWeights[perceptron] / (double)perceptronList.sumOfWeights[indexOfHighestValue] < 1.0001)
                //{
                //    return -1;

                //}
            }
            return indexOfHighestValue;
        }


/// <summary>
/// Here we can check what the draw of image is.
/// </summary>
/// <param name="sender"></param>
/// <param name="e"></param>
        private void DrawLetter_MouseUp(object sender, MouseEventArgs e)
        {
            mouseDown = false;
            calculateNewValues();

            checkWhatLetterIs();
            calculateFullSumOfWhitePixels(DrawLetter.Image);
        }

        private void calculateFullSumOfWhitePixels(Image image)
        {
            int sum = 0;
            for(int i = 0; i < image.Width; i++)
            {
                for (int j = 0; j < image.Height; j++)
                {
                    var pixel = ((Bitmap)image).GetPixel(i, j);
                    if(pixel.R == 255)
                    {
                        sum++;
                    }
                }
            }
            if (sum < (image.Width * image.Height)/15)
            {
               lblPrecise.Text = "Draw something more!";
            }
            else
            {
                lblPrecise.Text = "";
                lblPrecise.Enabled = false;
            }

        }

        /// <summary>
        /// Reset the DrawLetter image.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ResetImage_Click(object sender, EventArgs e)
        {
            DrawLetter = Drawings.DrawBlackInDrawLetter(DrawLetter);
            calculateNewValues();
        }
/// <summary>
/// Change size of the drawing pen.
/// </summary>
/// <param name="sender"></param>
/// <param name="e"></param>
        private void SizeOfPen_ValueChanged(object sender, EventArgs e)
        {
            SettingsDrawLetter.sizeOfPen = SizeOfPen.Value;
        }
    }
}
